
if (window.jsb) {
    require("src/assets/maingamez.js");
    window.startGameZ();
  }
